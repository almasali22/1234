from flask import Flask, render_template, request, redirect, url_for, session, send_file
import pandas as pd
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

EXCEL_FILE = 'repairs.xlsx'

# لیست یوزرها
USERS = {
    'admin1': '0000',
    'admin2': 'pass2',
    'admin3': 'pass3'
}

# 📋 بررسی وجود فایل اکسل و ساخت در صورت نبودن
def get_or_create_excel():
    if not os.path.exists(EXCEL_FILE):
        df = pd.DataFrame(columns=["نام", "نام خانوادگی", "شماره", "دستگاه", "مشکل", "کد پیگیری", "وضعیت"])
        df.to_excel(EXCEL_FILE, index=False)
    return pd.read_excel(EXCEL_FILE)

# 🏠 صفحه اصلی فرم ثبت تعمیرات
@app.route("/", methods=["GET", "POST"])
def form():
    if request.method == "POST":
        phone = request.form["phone"]

        if not (phone.isdigit() and len(phone) == 11 and phone.startswith("09")):
            error = "فرمت شماره وارد شده نادرست است. لطفاً شماره موبایل را صحیح وارد کنید."
            return render_template("form.html", error=error)

        df = get_or_create_excel()

        if df.empty:
            next_code = 405
        else:
            last_code = df["کد پیگیری"].iloc[-1]
            try:
                last_number = int(last_code.replace("P", ""))
                next_code = last_number + 1
            except:
                next_code = 404

        code = f"P{next_code}"

        data = {
            "نام": request.form["name"],
            "نام خانوادگی": request.form["lastname"],
            "شماره": phone,
            "دستگاه": request.form["device"],
            "مشکل": request.form["issue"],
            "کد پیگیری": code,
            "وضعیت": "در حال بررسی"
        }

        df.loc[len(df)] = data
        df.to_excel(EXCEL_FILE, index=False)
        return render_template("success.html", name=data["نام"], code=code)

    # این خط درست است و باید در پایان تابع باشد
    return render_template("form.html", error=None)
# 🔍 جستجوی سفارش بر اساس شماره یا کد پیگیری
@app.route("/search", methods=["GET", "POST"])
def search():
    if request.method == "POST":
        query = request.form["query"].strip()
        df = get_or_create_excel()

        # تبدیل همه ستون‌ها به رشته
        df = df.astype(str)

        # فیلتر با دقت بالا
        results = df[
            df["شماره"].str.contains(query, case=False, na=False) |
            df["کد پیگیری"].str.lower().str.contains(query.lower(), na=False)
        ]

        return render_template("result.html", results=results.to_dict(orient='records'), query=query)

    return render_template("search.html")


# 🔐 ورود به پنل ادمین
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in USERS and USERS[username] == password:
            session['logged_in'] = True
            session['username'] = username
            return redirect(url_for('admin_dashboard'))
        else:
            error = 'نام کاربری یا رمز عبور اشتباه است'
    return render_template('login.html', error=error)

# 🧭 داشبورد اصلی ادمین
@app.route('/admin')
def admin_dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('admin_dashboard.html')

# 🧾 مشاهده تعمیرات
@app.route('/admin/repairs', methods=["GET", "POST"])
def admin_repairs():
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    df = get_or_create_excel()

    if request.method == 'POST':
        code = request.form['code']
        new_status = request.form['status']
        df.loc[df['کد پیگیری'] == code, 'وضعیت'] = new_status
        df.to_excel(EXCEL_FILE, index=False)

    data = df.to_dict(orient='records')
    statuses = ['در حال بررسی', 'در حال تعمیر', 'تحویل داده شده', 'آماده تحویل', 'لغو شده']
    return render_template('admin_repairs.html', repairs=data, statuses=statuses)

# 📥 دریافت فایل اکسل کامل
@app.route('/download-report')
def download_report():
    get_or_create_excel()
    return send_file(EXCEL_FILE, as_attachment=True)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
